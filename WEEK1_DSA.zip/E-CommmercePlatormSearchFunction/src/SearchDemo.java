import java.util.Arrays;
import java.util.Scanner;

// Class to represent a Product with id and name
class Product {
    private String productId;
    private String productName;

    public Product(String productId, String productName) {
        this.productId = productId;
        this.productName = productName;
    }

    public String getProductId() {
        return productId;
    }

    public String getProductName() {
        return productName;
    }

    //for better display override tostring
    public String toString() {
        return "Product [productId=" + productId + ", productName=" + productName + "]";
    }
}

class SearchAlgorithms {

    // Linear search implementation
    public static Product linearSearch(Product[] products, String productName) {
        for (Product product : products) {
            if (product.getProductName().equalsIgnoreCase(productName)) {
                return product;
            }
        }
        return null;
    }

    // Binary search implementation
    public static Product binarySearch(Product[] products, String productName) {
        /*Arrays.sort uses the Comparator provided to determine the order of the elements in the array. 
        In this case, the lambda expression specifies that the sorting should be based on the product names, 
        and it should ignore case differences. */
        Arrays.sort(products, (p1, p2) -> p1.getProductName().compareToIgnoreCase(p2.getProductName()));
        return binarySearchRecursive(products, productName, 0, products.length - 1);
    }

    private static Product binarySearchRecursive(Product[] products, String productName, int left, int right) {
        if (left <= right) {
            int mid = left + (right - left) / 2;
            int comparison = products[mid].getProductName().compareToIgnoreCase(productName);
            if (comparison == 0) {
                return products[mid];
            } else if (comparison < 0) {
                return binarySearchRecursive(products, productName, mid + 1, right);
            } else {
                return binarySearchRecursive(products, productName, left, mid - 1);
            }
        }
        return null;
    }
}

public class SearchDemo {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        Product[] products = {
            new Product("1", "Laptop"),
            new Product("2", "Headphones"),
            new Product("3", "Keyboard"),
            new Product("4", "Monitor"),
            new Product("5", "Mouse")
        };

        System.out.println("Enter the product name to search:");
        String searchName = scanner.nextLine().trim();

        // Perform Linear Search
        Product linearSearchResult = SearchAlgorithms.linearSearch(products, searchName);
        if (linearSearchResult != null) {
            System.out.println("Linear Search: Found - " + linearSearchResult);
        } else {
            System.out.println("Linear Search: Product not found");
        }

        // Perform Binary Search
        Product binarySearchResult = SearchAlgorithms.binarySearch(products, searchName);
        if (binarySearchResult != null) {
            System.out.println("Binary Search: Found - " + binarySearchResult);
        } else {
            System.out.println("Binary Search: Product not found");
        }

        scanner.close();
    }
}
