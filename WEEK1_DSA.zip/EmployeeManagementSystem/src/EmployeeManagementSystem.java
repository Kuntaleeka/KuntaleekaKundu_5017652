public class EmployeeManagementSystem {
    private Employee[] employees;
    private int size;  // Tracks the number of employees currently in the array

    public EmployeeManagementSystem(int capacity) {
        employees = new Employee[capacity];
        size = 0;
    }

    // Add an employee
    public void addEmployee(Employee employee) {
        if (size < employees.length) {
            employees[size++] = employee;
        } else {
            System.out.println("Array is full. Cannot add more employees.");
        }
    }

    // Search for an employee by ID
    public Employee searchEmployeeById(int employeeId) {
        for (int i = 0; i < size; i++) {
            if (employees[i].getEmployeeId() == employeeId) {
                return employees[i];
            }
        }
        return null;  // Employee not found
    }

    // Traverse and display all employees
    public void displayEmployees() {
        for (int i = 0; i < size; i++) {
            System.out.println(employees[i]);
        }
    }

    // Delete an employee by ID
    public void deleteEmployeeById(int employeeId) {
        int indexToDelete = -1;
        for (int i = 0; i < size; i++) {
            if (employees[i].getEmployeeId() == employeeId) {
                indexToDelete = i;
                break;
            }
        }
        
        if (indexToDelete == -1) {
            System.out.println("Employee not found.");
            return;
        }
        
        // Shift elements left
        for (int i = indexToDelete; i < size - 1; i++) {
            employees[i] = employees[i + 1];
        }
        employees[size - 1] = null;  // Clear last element
        size--;
    }
    
        public static void main(String[] args) {
            // Create an instance of EmployeeManagementSystem with a capacity of 5
            EmployeeManagementSystem ems = new EmployeeManagementSystem(5);
    
            // Create some Employee objects
            Employee emp1 = new Employee(101, "Kuntaleeka Kundu", "Developer", 60000);
            Employee emp2 = new Employee(102, "Pinaki Pritamm Singha", "Designer", 55000);
            Employee emp3 = new Employee(103, "Abhishek Guha", "Manager", 75000);
            Employee emp4 = new Employee(104, "Sayantan Maity", "Analyst", 50000);
            Employee emp5 = new Employee(105, "Maria Mazumder", "HR", 52000);
    
            // Add employees to the system
            ems.addEmployee(emp1);
            ems.addEmployee(emp2);
            ems.addEmployee(emp3);
            ems.addEmployee(emp4);
            ems.addEmployee(emp5);
    
            // Display all employees
            System.out.println("All Employees:");
            ems.displayEmployees();
    
            // Search for an employee by ID
            int searchId = 103;
            Employee foundEmployee = ems.searchEmployeeById(searchId);
            if (foundEmployee != null) {
                System.out.println("Employee with ID " + searchId + ": " + foundEmployee);
            } else {
                System.out.println("Employee with ID " + searchId + " not found.");
            }
    
            // Delete an employee by ID
            int deleteId = 102;
            ems.deleteEmployeeById(deleteId);
            System.out.println("Deleted employee with ID " + deleteId + ".");
    
            // Display all employees after deletion
            System.out.println("All Employees after deletion:");
            ems.displayEmployees();
        }
    }
    
