public class FinancialForecast {
    
    // Public method to be called by the user
    public static double predictFutureValue(double initialValue, double growthRate, int periods) {
        // Validate input
        if (initialValue <= 0 || growthRate < 0 || periods < 0) {
            throw new IllegalArgumentException("Invalid input: All values must be non-negative, and initialValue must be positive.");
        }
        // Call the helper method
        return predictFutureValueHelper(initialValue, growthRate, periods);
    }

    // Private helper method to perform the recursion
    private static double predictFutureValueHelper(double value, double growthRate, int periods) {
        // Base Case: When no more periods are left
        if (periods == 0) {
            return value;
        }
        // Recursive Case: Apply growth rate and reduce the period
        return predictFutureValueHelper(value * (1 + growthRate), growthRate, periods - 1);
    }

    public static void main(String[] args) {
        double initialValue = 2500; // Example initial value
        double growthRate = 0.02;   // 2% growth rate
        int periods = 12;           // Number of periods

        double futureValue = predictFutureValue(initialValue, growthRate, periods);
        System.out.println("Future Value: " + futureValue);
    }
}
