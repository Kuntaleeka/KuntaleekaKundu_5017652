import java.util.HashMap;
import java.util.Map;

public class Inventory {
    private Map<String, Product> inventory;

    public Inventory() {
        inventory = new HashMap<>();
    }

    // Method to add a new product to the inventory
    public void addProduct(Product product) {
        if (inventory.containsKey(product.getProductId())) {
            System.out.println("Product with ID " + product.getProductId() + " already exists.");
        } else {
            inventory.put(product.getProductId(), product);
            System.out.println("Product added: " + product);
        }
    }

    // Method to update an existing product in the inventory
    public void updateProduct(String productId, Product updatedProduct) {
        if (inventory.containsKey(productId)) {
            inventory.put(productId, updatedProduct);
            System.out.println("Product updated: " + updatedProduct);
        } else {
            System.out.println("Product with ID " + productId + " not found.");
        }
    }

    // Method to delete a product from the inventory
    public void deleteProduct(String productId) {
        if (inventory.containsKey(productId)) {
            Product removedProduct = inventory.remove(productId);
            System.out.println("Product deleted: " + removedProduct);
        } else {
            System.out.println("Product with ID " + productId + " not found.");
        }
    }

    // Method to retrieve a product from the inventory
    public Product getProduct(String productId) {
        if (inventory.containsKey(productId)) {
            return inventory.get(productId);
        } else {
            System.out.println("Product with ID " + productId + " not found.");
            return null;
        }
    }

    // Method to display all products in the inventory
    public void displayInventory() {
        if (inventory.isEmpty()) {
            System.out.println("Inventory is empty.");
        } else {
            System.out.println("Current Inventory:");
            for (Product product : inventory.values()) {
                System.out.println(product);
            }
        }
    }

    public static void main(String[] args) {
        Inventory inv = new Inventory();

        Product p1 = new Product("1", "Gaming Laptop", 5, 1499.99);
        Product p2 = new Product("2", "Bluetooth Headphones", 100, 59.99);
        Product p3 = new Product("3", "Mechanical Keyboard", 40, 129.99);
        Product p4 = new Product("4", "4K Monitor", 15, 399.99);

        // Adding products to the inventory
        inv.addProduct(p1);
        inv.addProduct(p2);
        inv.addProduct(p3);
        inv.addProduct(p4);

        // Displaying the inventory
        inv.displayInventory();

        // Updating a product in the inventory
        p1.setQuantity(3);
        inv.updateProduct("1", p1);

        // Displaying the inventory after update
        inv.displayInventory();

        // Deleting a product from the inventory
        inv.deleteProduct("2");

        // Displaying the inventory after deletion
        inv.displayInventory();
    }
}
