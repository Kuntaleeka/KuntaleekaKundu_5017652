import java.util.ArrayList;
import java.util.List;
import java.util.Collections;
import java.util.Scanner;

public class Library {
    // Linear search method to find a book by title
    public static Book linearSearchByTitle(List<Book> books, String title) {
        for (Book book : books) {
            if (book.getTitle().equalsIgnoreCase(title)) {
                return book;
            }
        }
        return null; // Book not found
    }

    // Binary search method to find a book by title
    public static Book binarySearchByTitle(List<Book> books, String title) {
        // Ensure the list is sorted by title
        Collections.sort(books, (b1, b2) -> b1.getTitle().compareToIgnoreCase(b2.getTitle()));

        int left = 0;
        int right = books.size() - 1;

        while (left <= right) {
            int mid = left + (right - left) / 2;
            Book midBook = books.get(mid);

            int comparison = midBook.getTitle().compareToIgnoreCase(title);

            if (comparison == 0) {
                return midBook; // Book found
            } else if (comparison < 0) {
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }
        return null; // Book not found
    }

    public static void main(String[] args) {
        // Create a list of books
        List<Book> books = new ArrayList<>();
        books.add(new Book(1, "Moby Dick", "Herman Melville"));
        books.add(new Book(2, "War and Peace", "Leo Tolstoy"));
        books.add(new Book(3, "The Odyssey", "Homer"));
        books.add(new Book(4, "Brave New World", "Aldous Huxley"));
        books.add(new Book(5, "The Catch-22", "Joseph Heller"));

        Scanner scanner = new Scanner(System.in);

        // User input for linear search
        System.out.print("Enter book title to search (Linear Search): ");
        String searchTitleLinear = scanner.nextLine();
        Book resultLinear = Library.linearSearchByTitle(books, searchTitleLinear);
        if (resultLinear != null) {
            System.out.println("Linear Search: Book found - " + resultLinear.getTitle() + " by " + resultLinear.getAuthor());
        } else {
            System.out.println("Linear Search: Book not found");
        }

        // User input for binary search
        System.out.print("Enter book title to search (Binary Search): ");
        String searchTitleBinary = scanner.nextLine();
        
        // Ensure the list is sorted by title for binary search
        Collections.sort(books, (b1, b2) -> b1.getTitle().compareToIgnoreCase(b2.getTitle()));
        Book resultBinary = Library.binarySearchByTitle(books, searchTitleBinary);
        if (resultBinary != null) {
            System.out.println("Binary Search: Book found - " + resultBinary.getTitle() + " by " + resultBinary.getAuthor());
        } else {
            System.out.println("Binary Search: Book not found");
        }

        scanner.close();
    }
}