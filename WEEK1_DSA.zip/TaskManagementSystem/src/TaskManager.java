public class TaskManager {
    private Node head;

    public TaskManager() {
        this.head = null;
    }

    // Add a new task
    public void addTask(Task task) {
        Node newNode = new Node(task);
        if (head == null) {
            head = newNode;
        } else {
            Node current = head;
            while (current.next != null) {
                current = current.next;
            }
            current.next = newNode;
        }
    }

    // Search for a task by ID
    public Task searchTask(int taskId) {
        Node current = head;
        while (current != null) {
            if (current.task.taskId == taskId) {
                return current.task;
            }
            current = current.next;
        }
        return null; // Task not found
    }

    // Traverse and print all tasks
    public void traverseTasks() {
        Node current = head;
        while (current != null) {
            System.out.println(current.task);
            current = current.next;
        }
    }

    // Delete a task by ID
    public void deleteTask(int taskId) {
        if (head == null) return;

        if (head.task.taskId == taskId) {
            head = head.next;
            return;
        }

        Node current = head;
        while (current.next != null && current.next.task.taskId != taskId) {
            current = current.next;
        }

        if (current.next != null) {
            current.next = current.next.next;
        }
    }
    public static void main(String[] args) {
        // Create a TaskManager instance
        TaskManager taskManager = new TaskManager();

        // Create and add tasks
        Task task1 = new Task(1, "Complete Assignments", "Pending");
        Task task2 = new Task(2, "Read Book", "In Progress");
        Task task3 = new Task(3, "Workout", "Completed");

        taskManager.addTask(task1);
        taskManager.addTask(task2);
        taskManager.addTask(task3);

        // Print all tasks
        System.out.println("All tasks:");
        taskManager.traverseTasks();

        // Search for a task
        int searchId = 2;
        Task searchedTask = taskManager.searchTask(searchId);
        if (searchedTask != null) {
            System.out.println("\nFound task with ID " + searchId + ":");
            System.out.println(searchedTask);
        } else {
            System.out.println("\nTask with ID " + searchId + " not found.");
        }

        // Delete a task
        int deleteId = 1;
        taskManager.deleteTask(deleteId);
        System.out.println("\nTasks after deleting task with ID " + deleteId + ":");
        taskManager.traverseTasks();
    }
}

