package com.library.repository;

public class BookRepository {
	 public String getBook() {
	        return "Book details from the repository";
	    }
}
