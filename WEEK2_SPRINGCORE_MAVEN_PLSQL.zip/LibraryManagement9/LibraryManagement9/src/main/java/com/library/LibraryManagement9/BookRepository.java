package com.library.LibraryManagement9;

public interface BookRepository {

}
