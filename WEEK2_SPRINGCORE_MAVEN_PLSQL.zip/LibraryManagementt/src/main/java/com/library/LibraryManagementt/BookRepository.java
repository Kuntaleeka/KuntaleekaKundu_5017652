package com.library.LibraryManagementt;

import org.springframework.stereotype.Repository;

@Repository
public class BookRepository {
	public void printMessage(String message) {
        System.out.println(message);
    }

}
