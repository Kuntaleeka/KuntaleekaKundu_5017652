package com.library.LibraryManagementt;

import org.springframework.stereotype.Service;

@Service
public class BookService {

    private BookRepository bookRepository;
    
    // Constructor injection
    public BookService(BookRepository bookRepository) {
        this.bookRepository = bookRepository;
    }

    // Setter method for BookRepository
    public void setBookRepository(BookRepository bookRepository) {
        this.bookRepository = bookRepository;
    }
    
    // Method to print a message
    public void printMessage(String message) {
        System.out.println(message);
    }
}
