package com.library.LibraryManagementt;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class LibraryManagementApplication{

	    public static void main(String[] args) {
	        // Load the Spring context from applicationContext.xml
	        ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");

	        // Retrieve the BookService bean
	        BookService bookService = context.getBean(BookService.class);

	        // Use the bookService instance to verify if it's configured correctly
	        System.out.println("BookService instance: " + bookService);
	        
	        // Use the BookService and BookRepository beans
	        bookService.printMessage("Hello from BookService!");
	        
	        // Call a method to trigger logging aspect
	        bookService.printMessage("Testing AOP Logging");
	        
	        // Retrieve the BookRepository bean to verify it's availability
	        BookRepository bookRepository = context.getBean(BookRepository.class);
	        bookRepository.printMessage("Hello from BookRepository!");
	        bookRepository.printMessage("Testing AOP Logging for BookRepository");
	    }
	}

