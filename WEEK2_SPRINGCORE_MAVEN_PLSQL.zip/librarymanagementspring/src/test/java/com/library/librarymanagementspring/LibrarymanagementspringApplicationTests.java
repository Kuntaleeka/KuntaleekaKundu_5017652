package com.library.librarymanagementspring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LibrarymanagementspringApplicationTests {

	@Test
	void contextLoads() {
	}

}
