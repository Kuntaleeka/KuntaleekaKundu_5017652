package com.bookstoreapi.BookStoreAPI.controller;

import com.bookstoreapi.BookStoreAPI.dto.BookDTO;
import com.bookstoreapi.BookStoreAPI.service.BookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.hateoas.server.mvc.WebMvcLinkBuilder;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;

import java.util.List;

@RestController
@RequestMapping("/books")
public class BookController {

    @Autowired
    private BookService bookService;
    
    @Operation(summary = "Get all books", description = "Retrieve a list of all books, optionally filtered by title or author")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Successful retrieval of books",
                content = { @Content(mediaType = "application/json",
                schema = @Schema(implementation = BookDTO.class)) }),
        @ApiResponse(responseCode = "400", description = "Invalid input"),
        @ApiResponse(responseCode = "500", description = "Server error")
    })

    @GetMapping(produces = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE})
    public ResponseEntity<List<BookDTO>> getAllBooks(
            @RequestParam(required = false) String title,
            @RequestParam(required = false) String author) {
        List<BookDTO> books = bookService.findBooks(title, author);
        HttpHeaders headers = new HttpHeaders();
        headers.add("X-Total-Count", String.valueOf(books.size())); // Custom header to indicate the number of books
        headers.add("X-Request-ID", "12345"); // Example custom header for tracking requests
        
        books.forEach(book -> book.add(
                WebMvcLinkBuilder.linkTo(WebMvcLinkBuilder.methodOn(BookController.class).getBookById(book.getId())).withSelfRel()
            ));
        return ResponseEntity.ok()
                .headers(headers)
                .body(books);
    }
    @Operation(summary = "Get a book by ID", description = "Retrieve a single book by its ID")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Book found",
                content = { @Content(mediaType = "application/json",
                schema = @Schema(implementation = BookDTO.class)) }),
        @ApiResponse(responseCode = "404", description = "Book not found"),
        @ApiResponse(responseCode = "500", description = "Server error")
    })


    @GetMapping(value = "/{id}", produces = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE})
    public ResponseEntity<BookDTO> getBookById(@PathVariable Long id) {
        BookDTO bookDTO = bookService.findBookById(id);
        if (bookDTO == null) {
            HttpHeaders headers = new HttpHeaders();
            headers.add("X-Error-Code", "BOOK_NOT_FOUND"); // Custom error header
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .headers(headers)
                    .build();
        }
        bookDTO.add(
                WebMvcLinkBuilder.linkTo(WebMvcLinkBuilder.methodOn(BookController.class).getBookById(id)).withSelfRel(),
                WebMvcLinkBuilder.linkTo(WebMvcLinkBuilder.methodOn(BookController.class).getAllBooks(null, null)).withRel("all-books")
            );
        return ResponseEntity.ok()
                .header("X-Book-Found", "true") // Custom header to indicate successful retrieval
                .body(bookDTO);
    }
    
    @Operation(summary = "Create a new book", description = "Add a new book to the collection")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "201", description = "Book successfully created",
                content = { @Content(mediaType = "application/json",
                schema = @Schema(implementation = BookDTO.class)) }),
        @ApiResponse(responseCode = "400", description = "Invalid input"),
        @ApiResponse(responseCode = "500", description = "Server error")
    })

    @PostMapping(consumes = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE},
                 produces = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE})
    public ResponseEntity<BookDTO> createBook(@RequestBody BookDTO bookDTO) {
        BookDTO createdBook = bookService.createBook(bookDTO);
        HttpHeaders headers = new HttpHeaders();
        headers.add("X-Resource-ID", String.valueOf(createdBook.getId())); // Header indicating resource ID of the newly created book
        headers.add("X-Operation-Status", "Created"); // Status of the creation operation
        createdBook.add(
                WebMvcLinkBuilder.linkTo(WebMvcLinkBuilder.methodOn(BookController.class).getBookById(createdBook.getId())).withSelfRel()
            );
        return ResponseEntity.status(HttpStatus.CREATED)
                .headers(headers)
                .body(createdBook);
    }
    
    @Operation(summary = "Update a book", description = "Update an existing book by its ID")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Book successfully updated",
                content = { @Content(mediaType = "application/json",
                schema = @Schema(implementation = BookDTO.class)) }),
        @ApiResponse(responseCode = "404", description = "Book not found"),
        @ApiResponse(responseCode = "400", description = "Invalid input"),
        @ApiResponse(responseCode = "500", description = "Server error")
    })

    @PutMapping(value = "/{id}", consumes = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE},
                produces = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE})
    public ResponseEntity<BookDTO> updateBook(@PathVariable Long id, @RequestBody BookDTO bookDTO) {
        BookDTO updatedBook = bookService.updateBook(id, bookDTO);
        if (updatedBook == null) {
            HttpHeaders headers = new HttpHeaders();
            headers.add("X-Error-Code", "UPDATE_FAILED"); // Custom error header
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .headers(headers)
                    .build();
        }
        updatedBook.add(
                WebMvcLinkBuilder.linkTo(WebMvcLinkBuilder.methodOn(BookController.class).getBookById(id)).withSelfRel()
            );
        return ResponseEntity.ok()
                .header("X-Update-Status", "Success") // Custom header indicating update success
                .body(updatedBook);
    }
    @Operation(summary = "Delete a book", description = "Delete a book by its ID")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "204", description = "Book successfully deleted"),
        @ApiResponse(responseCode = "404", description = "Book not found"),
        @ApiResponse(responseCode = "500", description = "Server error")
    })

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteBook(@PathVariable Long id) {
        if (bookService.findBookById(id) == null) {
            HttpHeaders headers = new HttpHeaders();
            headers.add("X-Error-Code", "DELETE_FAILED"); // Custom error header
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .headers(headers)
                    .build();
        }
        bookService.deleteBook(id);
        return ResponseEntity.noContent()
                .header("X-Operation-Status", "Deleted") // Custom header indicating deletion success
                .build();
    }
}
