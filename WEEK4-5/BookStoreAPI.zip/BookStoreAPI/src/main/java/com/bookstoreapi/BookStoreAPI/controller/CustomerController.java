package com.bookstoreapi.BookStoreAPI.controller;


import com.bookstoreapi.BookStoreAPI.dto.CustomerDTO;
import com.bookstoreapi.BookStoreAPI.service.CustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/customers")
public class CustomerController {

    @Autowired
    private CustomerService customerService;

    @PostMapping
    public ResponseEntity<CustomerDTO> createCustomer(@RequestBody CustomerDTO customerDTO) {
        return ResponseEntity.status(201).body(customerService.createCustomer(customerDTO));
    }

    @PostMapping("/register")
    public ResponseEntity<Void> registerCustomer(@RequestParam String name, @RequestParam String email) {
        customerService.registerCustomer(name, email);
        return ResponseEntity.ok().build();
    }
}

