package com.bookstoreapi.BookStoreAPI.repository;

import com.bookstoreapi.BookStoreAPI.model.Book;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BookRepository extends JpaRepository<Book, Long> {
    // Custom query methods can be added here if needed
}
