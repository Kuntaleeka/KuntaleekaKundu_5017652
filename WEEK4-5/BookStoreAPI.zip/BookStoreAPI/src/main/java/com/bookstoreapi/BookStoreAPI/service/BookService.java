package com.bookstoreapi.BookStoreAPI.service;

import com.bookstoreapi.BookStoreAPI.dto.BookDTO;
import com.bookstoreapi.BookStoreAPI.model.Book;
import com.bookstoreapi.BookStoreAPI.repository.BookRepository;
import io.micrometer.core.instrument.MeterRegistry;
import io.micrometer.core.instrument.Gauge;
import io.micrometer.core.instrument.Counter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class BookService {

    @Autowired
    private BookRepository bookRepository;

    @Autowired
    private MeterRegistry meterRegistry;

    private static final String BOOK_COUNT_METRIC_NAME = "book.count";
    private static final String BOOK_PROCESSING_COUNT_METRIC_NAME = "book.processing.count";
    private final Counter bookProcessingCounter;
    private final Gauge bookCountGauge;

    public BookService(MeterRegistry meterRegistry) {
        this.meterRegistry = meterRegistry;
        this.bookProcessingCounter = meterRegistry.counter(BOOK_PROCESSING_COUNT_METRIC_NAME);
        this.bookCountGauge = Gauge.builder(BOOK_COUNT_METRIC_NAME, bookRepository, BookRepository::count)
                                   .register(meterRegistry);
    }

    public List<BookDTO> findBooks(String title, String author) {
        List<Book> books = bookRepository.findAll(); // Replace with specific query if needed
        bookProcessingCounter.increment(); // Increment custom counter
        return books.stream()
                .filter(book -> (title == null || book.getTitle().contains(title)) &&
                                (author == null || book.getAuthor().contains(author)))
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    public BookDTO findBookById(Long id) {
        Optional<Book> bookOptional = bookRepository.findById(id);
        return bookOptional.map(this::convertToDTO).orElse(null); // Or throw an exception
    }

    public BookDTO createBook(BookDTO bookDTO) {
        Book book = convertToEntity(bookDTO);
        Book savedBook = bookRepository.save(book);
        // Update gauge directly or use a custom counter if needed
        return convertToDTO(savedBook);
    }

    public BookDTO updateBook(Long id, BookDTO bookDTO) {
        if (!bookRepository.existsById(id)) {
            return null; // Or throw an exception
        }
        Book book = convertToEntity(bookDTO);
        book.setId(id);
        Book updatedBook = bookRepository.save(book);
        return convertToDTO(updatedBook);
    }

    public void deleteBook(Long id) {
        if (bookRepository.existsById(id)) {
            bookRepository.deleteById(id);
        } else {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Book not found");
        }
    }

    private BookDTO convertToDTO(Book book) {
        BookDTO dto = new BookDTO();
        dto.setId(book.getId());
        dto.setTitle(book.getTitle());
        dto.setAuthor(book.getAuthor());
        return dto;
    }

    private Book convertToEntity(BookDTO bookDTO) {
        Book book = new Book();
        book.setTitle(bookDTO.getTitle());
        book.setAuthor(bookDTO.getAuthor());
        return book;
    }
}
