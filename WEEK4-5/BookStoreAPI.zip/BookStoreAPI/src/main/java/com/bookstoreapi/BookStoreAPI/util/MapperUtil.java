package com.bookstoreapi.BookStoreAPI.util;

import com.bookstoreapi.BookStoreAPI.dto.BookDTO;
import com.bookstoreapi.BookStoreAPI.dto.CustomerDTO;
import com.bookstoreapi.BookStoreAPI.model.Book;
import com.bookstoreapi.BookStoreAPI.model.Customer;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface MapperUtil {

    MapperUtil INSTANCE = Mappers.getMapper(MapperUtil.class);

    // Book and BookDTO mappings
    BookDTO bookToBookDTO(Book book);
    Book bookDTOToBook(BookDTO bookDTO);

    // Customer and CustomerDTO mappings
    CustomerDTO customerToCustomerDTO(Customer customer);
    Customer customerDTOToCustomer(CustomerDTO customerDTO);
}
